<template>
   
    <nav>
        <div>
            <router-link class="link" to="/">Home Page</router-link>
        </div>
    </nav>
    <main>
        <router-view/>
    </main>
</template>